# pylint: disable=missing-module-docstring
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring

import os
import requests
import iptvklase


"""
interesantno
prazni VOD
http://billing.magiptv.net:80/stalker_portal,00:1A:79:32:39:32
čudan poziv ajax (call_http_err.php)
http://wizzards.xyz:8080,00:1A:79:4d:5e:79
"""

#lista = iptvklase.MacLista("http://m.suportline.xyz/stalker_portal","00:1A:79:0A:90:A5")
#lista = iptvklase.MacLista("http://alternator.pro:80","00:1A:79:1E:BE:B7")
#lista = iptvklase.MacLista("http://terapija.club","00:1A:79:50:82:9C")
#lista = iptvklase.MacLista("http://xui.eos-tv.com/eosstalkertv","00:1a:79:55:78:24")
#lista = iptvklase.MacLista("http://nacionalnaklasa.xyz:12974","00:1A:79:40:9A:6D")
#lista = iptvklase.MacLista("http://Eonlinebio.com:8000","00:1A:79:D2:1B:6D")
#lista = iptvklase.MacLista("http://romanija.xyz:25461","00:1a:79:4c:a0:4e")
#lista = iptvklase.MacLista("http://next-tv.xyz:25461","00:1A:79:41:FD:86")
#lista = iptvklase.MacLista("http://ky-iptv.com/portalstb","00:1A:79:40:21:B1")
#lista = iptvklase.MacLista("http://mysolutionsbn.xyz:12974/c","00:1A:79:48:52:0D")
#lista = iptvklase.MacLista("http://d4.dd4k.me/stalker_portal","00:1A:79:48:1B:D1")
#NOK!!! lista = iptvklase.MacLista("http://mag.link-tv.net:88/stalker_portal","00:1A:79:4B:84:5C")
#NOK!!! lista = iptvklase.MacLista("https://gmed.me:2053","00:1A:79:23:B8:7D")
#lista = iptvklase.MacLista("http://87.116.151.4/stalker_portal","00:1A:79:00:00:55")
#lista = iptvklase.MacLista("http://flus4.xyz/stalker_portal","00:1A:79:54:13:A7")
#lista = iptvklase.MacLista("http://ip.tv2c.xyz:8080/BoSSxxxx","00:1A:79:60:63:5E")
#NOK!!! lista = iptvklase.MacLista("http://alternator.pro/server","00:1a:79:d5:2f:ac")
#lista = iptvklase.MacLista("http://deltatv.co.uk:80/powerfull","00:1A:79:C0:64:36")
#lista = iptvklase.MacLista("http://87.116.151.4:88/stalker_portal","00:1a:79:71:f0:6c")
#lista = iptvklase.MacLista("http://deltatv.co.uk:80/magportal","00:1A:79:70:87:C0")
#lista = iptvklase.MacLista("http://lhdp117.com/stalker_portal","00:1A:79:50:82:9C")
#lista = iptvklase.MacLista("http://tv.nova-iptv.com","00:1A:79:29:10:C9")
lista=iptvklase.MacLista(url="http://king.viviotv.xyz",mac="00:1A:79:A2:93:A2",user_agent="Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")

# response = requests.get("http://samsonin.dyndns.org:15094/SHARE/IptvListe/macliste.txt", timeout=5)
# response.raise_for_status()
# lines = response.text.splitlines()
# addresses = []
# for line in lines:
#     line=iptvklase.extract_http_part(line)
#     parts = line.split(',')
#     if len(parts) == 2:
#         url, mac = parts
#         # Use IpTvKlase.Address
#         addresses.append(iptvklase.Address(url.strip(), mac.strip()))
#     else:
#         print(f"Skipping malformed line: {line}")


lista.inicijaliziraj_listu()
if lista.live_categories:
    print(lista.live_categories["js"])
    h=lista.headers
    url=lista.url
else:
    print ("Ako u playeru ima kategorija listu nisam dobro obradio")


# while True:
#     l=input("Unesi listu u obliku http://tv.nova-iptv.com,00:1A:79:29:10:C9 (kao za Gogo player ili tester): ")
#     if not l:
#         exit()
#     polje=l.split(",")
#     lista=iptvklase.MacLista(polje[0],polje[1])
#     lista.inicijaliziraj_listu()
#     if lista.live_categories:
#         print(lista.live_categories["js"])
#     else:
#         print ("Ako u playeru ima kategorija listu nisam dobro obradio")
