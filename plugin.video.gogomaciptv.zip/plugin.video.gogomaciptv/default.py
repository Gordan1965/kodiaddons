# pylint: disable=missing-module-docstring
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring

import urllib.parse
import sys
import os
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmc
import xbmcvfs
import requests
import iptvklase


addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
userdata_path = xbmcvfs.translatePath('special://userdata/')
xbmc.log(f"ud: {userdata_path}", xbmc.LOGINFO)
addon_data_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
xbmc.log(f"ad: {addon_data_dir}", xbmc.LOGERROR)
home_path = xbmcvfs.translatePath('special://home/')
xbmc.log(f"hp: {home_path}", xbmc.LOGINFO)
cacheDir = os.path.join(addon_data_dir, "cache")
if not os.path.exists(cacheDir):
    xbmc.log(f"cache: {cacheDir}", xbmc.LOGERROR)
    os.makedirs(cacheDir)


def load_from_internet():
    adresa_lista = addon.getSetting("internetAdresa")
    if not adresa_lista:
        xbmcgui.Dialog().notification("Error",
                                        "Please configure the URL in addon settings", xbmcgui.NOTIFICATION_ERROR, 5000)
        addon.openSettings()
        adresa_lista = addon.getSetting("internetAdresa")
    if not adresa_lista:
        xbmcgui.Dialog().notification("Error", "No URL configured. Exiting addon.",
                                        xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()

    try:
        response = requests.get(adresa_lista, timeout=5)
        response.raise_for_status()
        lines = response.text.splitlines()
        addresses = []
        for line in lines:
            line=iptvklase.extract_http_part(line)
            parts = line.split(',')
            if len(parts) == 2:
                url, mac = parts
                # Use IpTvKlase.Address
                addresses.append(iptvklase.Address(url.strip(), mac.strip()))
            else:
                xbmc.log(f"Skipping malformed line: {line}", xbmc.LOGWARNING)
        return addresses
    except requests.RequestException as e:
        xbmc.log(f"Failed to fetch addresses: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch addresses from the URL",
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()

def load_from_local_storage():
    adresa_lista = addon.getSetting("lokalnaAdresa")
    if not adresa_lista:
        xbmcgui.Dialog().notification("Error",
                                        "Please configure the path in addon settings", xbmcgui.NOTIFICATION_ERROR, 5000)
        addon.openSettings()
        adresa_lista = addon.getSetting("lokalnaAdresa")
    if not adresa_lista:
        xbmcgui.Dialog().notification("Error", "No path configured. Exiting addon.",
                                        xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()
    try:
        # Otvori datoteku za čitanje
        with open(adresa_lista, "r") as file:
            # Čitaj sve linije iz datoteke i spremi ih u listu
            lines = file.readlines()
        addresses = []
        for line in lines:
            line=iptvklase.extract_http_part(line)
            parts = line.split(',')
            if len(parts) == 2:
                url, mac = parts
                # Use IpTvKlase.Address
                addresses.append(iptvklase.Address(url.strip(), mac.strip()))
            else:
                xbmc.log(f"Skipping malformed line: {line}", xbmc.LOGWARNING)
        return addresses
    except requests.RequestException as e:
        xbmc.log(f"Failed to fetch addresses: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch addresses from the URL",
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()


def load_addresses():
    izvor_tip = addon.getSetting("izvorTip")
    if izvor_tip=="0":
        return load_from_internet()
    else:
        return load_from_local_storage()
        


# Function to list unique servers
def get_unique_ordered_urls(addresses):
    unique_urls = []
    seen_urls = set()
    
    for address in addresses:
        if address.url not in seen_urls:
            unique_urls.append(address.url)
            seen_urls.add(address.url)
    
    return unique_urls

def list_servers(addresses):
    #unique_urls = {address.url for address in addresses}
    unique_urls = get_unique_ordered_urls(addresses)
    for index, url in enumerate(unique_urls, start=1):
        server_url = sys.argv[0] + f'?action=list_macs&server={url}'
        li = xbmcgui.ListItem(f"{url}")
        xbmcplugin.addDirectoryItem(
            handle=addon_handle, url=server_url, listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
    #xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)
    # xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)


def list_macs(adrese, server):
    xbmcplugin.setPluginCategory(addon_handle, server)
    for index, url in enumerate(adrese, start=1):
        server_url = sys.argv[0] + \
            f'?action=list_categories&server={server}&mac={url.mac}'
        li = xbmcgui.ListItem(f"{url.mac}")
        xbmcplugin.addDirectoryItem(
            handle=addon_handle, url=server_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def list_categories(kategorije):
    for index, kategorija in enumerate(kategorije, start=1):
        if not kategorija["id"] == "*":
            server_url = sys.argv[0] + \
                f'?action=list_programs&categorie={kategorija["id"]}'
            k = kategorija["title"]
            li = xbmcgui.ListItem(f"{k}")
            xbmcplugin.addDirectoryItem(
                handle=addon_handle, url=server_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def list_programs(programi, kategorija):
    for index, program in enumerate(programi, start=1):
        if str(program["tv_genre_id"]) == kategorija:
            server_url = sys.argv[0] + \
                f'?action=play_program&programid={program["id"]}'
            k = program["name"]
            img = program["logo"]
            li = xbmcgui.ListItem(label=f"{k}", label2=f"{k}")
            li.setArt({
                'icon': img,
                'thumb': img
            })
            xbmcplugin.addDirectoryItem(
                handle=addon_handle, url=server_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def dodaj_praznu_kategoriju(programi,kategorija):
    for d in programi["js"]["data"]:
        if str(d["tv_genre_id"]) == kategorija:
            return
    server = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "server.txt"))
    headers = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "header.txt"))
    iptvklase.get_live_streams_in_group(kategorija,server["baseUrl"],headers,programi)
    iptvklase.spremi_dict_u_datoteku(
                    programi, os.path.join(cacheDir, "livechannels.txt"))
    


def router(paramstring, addresses):
    xbmc.log(f"{paramstring}", xbmc.LOGINFO)
    params = ""
    if paramstring:
        xbmc.log(f"{addon.getAddonInfo('id')}", xbmc.LOGINFO)
        params = dict(part.split('=') for part in paramstring[1:].split('&'))
    if not params:
        list_servers(addresses)
    else:
        action = params.get('action')
        xbmc.log(f"{action}", xbmc.LOGINFO)
        if action == 'list_macs':
            server = urllib.parse.unquote(params.get('server'))
            xbmc.log(f"{server}", xbmc.LOGINFO)
            server_addresses = [
                address for address in addresses if address.url == server]
            list_macs(server_addresses, server)
        elif action == 'list_categories':
            server = urllib.parse.unquote(params.get('server'))
            mac = urllib.parse.unquote(params.get('mac'))
            lista = iptvklase.MacLista(server, mac)
            lista.inicijaliziraj_listu()
            bazni_podaci = {
                'server': f'{server}',
                'mac': f'{mac}',
                'baseUrl': f'{lista.url}'
            }
            iptvklase.spremi_dict_u_datoteku(
                bazni_podaci, os.path.join(cacheDir, "server.txt"))
            iptvklase.spremi_dict_u_datoteku(
                dict(lista.session.headers), os.path.join(cacheDir, "header.txt"))
            if lista.live_channels:
                iptvklase.spremi_dict_u_datoteku(
                    lista.live_channels, os.path.join(cacheDir, "livechannels.txt"))
            if lista.vod_categories:
                iptvklase.spremi_dict_u_datoteku(
                    lista.vod_categories, os.path.join(cacheDir, "vodcategories.txt"))
            if lista.series_categories:
                iptvklase.spremi_dict_u_datoteku(
                    lista.series_categories, os.path.join(cacheDir, "seriescategories.txt"))
            if lista.live_categories:
                iptvklase.spremi_dict_u_datoteku(
                    lista.live_categories, os.path.join(cacheDir, "livecategories.txt"))
                list_categories(lista.live_categories["js"])
            else:
                xbmcgui.Dialog().notification("Obavijest",
                                              "Lista nema kategorija", xbmcgui.NOTIFICATION_INFO, 5000)
        elif action == "list_programs":
            idc = urllib.parse.unquote(params.get('categorie'))
            programi = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "livechannels.txt"))
            dodaj_praznu_kategoriju(programi,idc)
            list_programs(programi["js"]["data"], idc)
        elif action == "play_program":
            idp = urllib.parse.unquote(params.get('programid'))
            programi = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "livechannels.txt"))
            server = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "server.txt"))
            header = iptvklase.procitaj_dict_iz_datoteke(
                os.path.join(cacheDir, "header.txt"))
            found_program = {}
            
            for program in programi["js"]["data"]:
                if str(program["id"]) == idp:
                    found_program = program
                    break

            if found_program:
                cmd = found_program['cmd']
                link=cmd
                link=link.replace(" h", "+h")
                link=urllib.parse.quote(link)
                url=server["baseUrl"] + f"type=itv&action=create_link&forced_storage=undefined&download=0&cmd={link}&JsHttpRequest=1-xml"
                cmd=iptvklase.extract_http_part(cmd)
                xbmc.log(
                    f"naziv {found_program['name']}  cmd: {cmd}  cmd za url: {cmd} url: {url}", xbmc.LOGINFO)
                ls = iptvklase.get_live_stream_url(url, header)
                xbmc.log(
                    f"java script od get_live_tream_url: {ls}", xbmc.LOGINFO)
                url_programa=""
                try:
                    url_programa=ls["js"]["cmd"]
                except:
                    url_programa=""
                logo=""
                try:
                    logo=found_program["logo"]
                except:
                    logo=""                
                token=""
                if url_programa:
                    url_programa=iptvklase.extract_http_part(url_programa)
                    i = url_programa.find("?play")
                    if i != -1:
                        token= url_programa[i:]
                else:
                    url_programa=cmd
                if cmd.find("localhost")!=-1:
                    if iptvklase.is_valid_url(cmd):
                        url_programa=cmd + token
                else:
                    url_programa= cmd
                xbmc.log(f"url videa: {url_programa}", xbmc.LOGINFO)
                list_item = xbmcgui.ListItem(label=found_program['name'])
                xbmc.log(
                    f"logo URL: {logo}", xbmc.LOGINFO)
                if logo:
                    list_item.setArt({'icon': logo, 'fanart': logo})
                list_item.setInfo('video',
                                  {'title': found_program['name'],
                                   'plot': found_program['name']
                                  }
                                )
                # Postavljanje User-Agent zaglavlja
                headers = {'User-Agent': "Player (Linux; Android 7.1.2)"}
                list_item.setPath(url)
                xbmc.log(f"url za list item: {url}", xbmc.LOGINFO)
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                list_item.setProperty('inputstream.adaptive.stream_headers', '&'.join([f"{k}={v}" for k, v in headers.items()]))
                if url_programa.endswith("==.ts"):
                    url_programa = url_programa[:-3]
                xbmc.Player().play(url_programa,list_item)
                
            else:
                xbmc.log("program nije pronađen", xbmc.LOGINFO)


if __name__ == '__main__':
    adrese = load_addresses()
    router(sys.argv[2], adrese)
